self.__precacheManifest = [
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "42c9596810d593ebd899",
    "url": "/static/js/main.42c95968.chunk.js"
  },
  {
    "revision": "cb1d1314042b35946536",
    "url": "/static/js/1.cb1d1314.chunk.js"
  },
  {
    "revision": "42c9596810d593ebd899",
    "url": "/static/css/main.83790644.chunk.css"
  },
  {
    "revision": "244f556a4d5660ab9bd0a2e2606efd87",
    "url": "/index.html"
  }
];